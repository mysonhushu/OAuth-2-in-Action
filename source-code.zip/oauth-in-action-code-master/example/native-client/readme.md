* npm install -g cordova

* npm install ios-sim

* cordova platform add ios

* cordova plugin add cordova-plugin-inappbrowser

* cordova plugin add cordova-plugin-customurlscheme --variable URL_SCHEME=mynativeapp

* cordova run ios  
